﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

/// <summary>
/// Summary description for rep_pro_certification_checklists
/// </summary>
public class rep_pro_certification_checklists : DevExpress.XtraReports.UI.XtraReport
{
    private DevExpress.XtraReports.UI.DetailBand Detail;
    private DevExpress.XtraReports.UI.TopMarginBand TopMargin;
    private DevExpress.XtraReports.UI.BottomMarginBand BottomMargin;
    private DevExpress.DataAccess.Sql.SqlDataSource sqlDataSource1;
    private ReportHeaderBand reportHeaderBand1;
    private DetailReportBand detailReportBand1;
    private GroupHeaderBand groupHeaderBand1;
    private DetailBand detailBand1;
    private DetailReportBand detailReportBand2;
    private GroupHeaderBand groupHeaderBand2;
    private DetailBand detailBand2;
    private DetailReportBand detailReportBand5;
    private GroupHeaderBand groupHeaderBand5;
    private DetailBand detailBand5;
    private DetailReportBand detailReportBand6;
    private GroupHeaderBand groupHeaderBand6;
    private DetailBand detailBand6;
    private DetailReportBand detailReportBand7;
    private GroupHeaderBand groupHeaderBand7;
    private DetailBand detailBand7;
    private DetailReportBand detailReportBand8;
    private GroupHeaderBand groupHeaderBand8;
    private DetailBand detailBand8;
    private DetailReportBand detailReportBand9;
    private GroupHeaderBand groupHeaderBand9;
    private DetailBand detailBand9;
    private DetailReportBand detailReportBand10;
    private GroupHeaderBand groupHeaderBand10;
    private DetailBand detailBand10;
    private DetailReportBand detailReportBand11;
    private GroupHeaderBand groupHeaderBand11;
    private DetailBand detailBand11;
    private DetailReportBand detailReportBand12;
    private GroupHeaderBand groupHeaderBand12;
    private DetailBand detailBand12;
    private DetailReportBand detailReportBand13;
    private GroupHeaderBand groupHeaderBand13;
    private DetailBand detailBand13;
    private DetailReportBand detailReportBand14;
    private GroupHeaderBand groupHeaderBand14;
    private DetailBand detailBand14;
    private XRControlStyle Title;
    private XRControlStyle DetailCaption3;
    private XRControlStyle DetailData3;
    private XRControlStyle DetailData3_Odd;
    private XRControlStyle DetailCaptionBackground3;
    private XRControlStyle PageInfo;
    private PageHeaderBand PageHeader;
    private PageFooterBand PageFooter;
    private XRPageInfo xrPageInfo1;
    private XRLabel xrLabel7;
    private XRPageInfo xrPageInfo2;
    private XRLabel xrLabel8;
    private XRLabel xrLabel12;
    private XRLabel xrLabel2;
    private XRLabel xrLabel4;
    private XRLabel xrLabel3;
    private XRTable xrTable1;
    private XRTableRow xrTableRow1;
    private XRTableCell xrTableCell1;
    private XRLabel xrLabel13;
    private XRLabel xrLabel11;
    private XRLabel xrLabel10;
    private XRLabel xrLabel9;
    private XRTable xrTable2;
    private XRTableRow xrTableRow2;
    private XRTableCell xrTableCell2;
    private XRTableCell xrTableCell3;
    private XRTableCell xrTableCell4;
    private XRTableCell xrTableCell5;
    private GroupHeaderBand GroupHeader1;
    private XRLabel xrLabel6;
    private XRLabel xrLabel5;
    private XRLabel xrLabel1;
    private FormattingRule formattingRule1;

    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    public rep_pro_certification_checklists()
    {
        InitializeComponent();
        //
        // TODO: Add constructor logic here
        //
    }

    /// <summary> 
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
            this.components = new System.ComponentModel.Container();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery1 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column1 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression1 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table1 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column2 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression2 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column3 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression3 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column4 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression4 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery2 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column5 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression5 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table2 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column6 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression6 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column7 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression7 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column8 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression8 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column9 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression9 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column10 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression10 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column11 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression11 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column12 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression12 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column13 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression13 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column14 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression14 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column15 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression15 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table3 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column16 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression16 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column17 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression17 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column18 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression18 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column19 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression19 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column20 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression20 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table4 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column21 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression21 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column22 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression22 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column23 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression23 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column24 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression24 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table5 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column25 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression25 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column26 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression26 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column27 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression27 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column28 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression28 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table6 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column29 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression29 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column30 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression30 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column31 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression31 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column32 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression32 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column33 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression33 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table7 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column34 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression34 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Join join1 = new DevExpress.DataAccess.Sql.Join();
            DevExpress.DataAccess.Sql.RelationColumnInfo relationColumnInfo1 = new DevExpress.DataAccess.Sql.RelationColumnInfo();
            DevExpress.DataAccess.Sql.Join join2 = new DevExpress.DataAccess.Sql.Join();
            DevExpress.DataAccess.Sql.RelationColumnInfo relationColumnInfo2 = new DevExpress.DataAccess.Sql.RelationColumnInfo();
            DevExpress.DataAccess.Sql.Join join3 = new DevExpress.DataAccess.Sql.Join();
            DevExpress.DataAccess.Sql.RelationColumnInfo relationColumnInfo3 = new DevExpress.DataAccess.Sql.RelationColumnInfo();
            DevExpress.DataAccess.Sql.Join join4 = new DevExpress.DataAccess.Sql.Join();
            DevExpress.DataAccess.Sql.RelationColumnInfo relationColumnInfo4 = new DevExpress.DataAccess.Sql.RelationColumnInfo();
            DevExpress.DataAccess.Sql.Join join5 = new DevExpress.DataAccess.Sql.Join();
            DevExpress.DataAccess.Sql.RelationColumnInfo relationColumnInfo5 = new DevExpress.DataAccess.Sql.RelationColumnInfo();
            DevExpress.DataAccess.Sql.Sorting sorting1 = new DevExpress.DataAccess.Sql.Sorting();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression35 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Sorting sorting2 = new DevExpress.DataAccess.Sql.Sorting();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression36 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery3 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column35 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression37 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table8 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column36 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression38 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column37 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression39 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column38 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression40 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column39 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression41 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery4 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column40 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression42 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table9 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column41 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression43 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column42 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression44 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column43 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression45 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery5 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column44 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression46 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table10 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column45 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression47 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column46 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression48 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery6 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column47 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression49 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table11 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column48 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression50 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column49 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression51 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column50 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression52 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column51 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression53 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column52 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression54 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column53 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression55 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery7 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column54 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression56 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table12 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column55 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression57 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column56 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression58 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column57 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression59 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column58 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression60 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column59 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression61 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column60 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression62 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column61 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression63 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column62 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression64 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column63 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression65 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery8 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column64 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression66 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table13 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column65 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression67 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column66 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression68 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column67 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression69 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column68 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression70 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column69 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression71 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table14 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column70 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression72 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column71 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression73 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table15 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column72 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression74 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column73 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression75 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column74 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression76 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column75 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression77 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table16 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column76 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression78 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column77 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression79 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column78 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression80 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column79 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression81 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column80 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression82 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table17 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column81 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression83 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column82 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression84 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column83 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression85 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column84 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression86 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column85 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression87 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column86 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression88 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column87 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression89 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column88 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression90 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column89 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression91 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column90 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression92 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column91 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression93 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column92 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression94 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table18 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column93 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression95 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column94 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression96 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column95 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression97 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column96 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression98 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column97 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression99 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table19 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column98 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression100 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column99 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression101 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column100 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression102 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column101 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression103 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table20 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column102 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression104 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column103 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression105 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column104 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression106 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column105 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression107 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column106 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression108 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table21 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column107 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression109 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column108 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression110 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column109 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression111 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Join join6 = new DevExpress.DataAccess.Sql.Join();
            DevExpress.DataAccess.Sql.RelationColumnInfo relationColumnInfo6 = new DevExpress.DataAccess.Sql.RelationColumnInfo();
            DevExpress.DataAccess.Sql.Join join7 = new DevExpress.DataAccess.Sql.Join();
            DevExpress.DataAccess.Sql.RelationColumnInfo relationColumnInfo7 = new DevExpress.DataAccess.Sql.RelationColumnInfo();
            DevExpress.DataAccess.Sql.Join join8 = new DevExpress.DataAccess.Sql.Join();
            DevExpress.DataAccess.Sql.RelationColumnInfo relationColumnInfo8 = new DevExpress.DataAccess.Sql.RelationColumnInfo();
            DevExpress.DataAccess.Sql.Join join9 = new DevExpress.DataAccess.Sql.Join();
            DevExpress.DataAccess.Sql.RelationColumnInfo relationColumnInfo9 = new DevExpress.DataAccess.Sql.RelationColumnInfo();
            DevExpress.DataAccess.Sql.Join join10 = new DevExpress.DataAccess.Sql.Join();
            DevExpress.DataAccess.Sql.RelationColumnInfo relationColumnInfo10 = new DevExpress.DataAccess.Sql.RelationColumnInfo();
            DevExpress.DataAccess.Sql.Join join11 = new DevExpress.DataAccess.Sql.Join();
            DevExpress.DataAccess.Sql.RelationColumnInfo relationColumnInfo11 = new DevExpress.DataAccess.Sql.RelationColumnInfo();
            DevExpress.DataAccess.Sql.Join join12 = new DevExpress.DataAccess.Sql.Join();
            DevExpress.DataAccess.Sql.RelationColumnInfo relationColumnInfo12 = new DevExpress.DataAccess.Sql.RelationColumnInfo();
            DevExpress.DataAccess.Sql.Join join13 = new DevExpress.DataAccess.Sql.Join();
            DevExpress.DataAccess.Sql.RelationColumnInfo relationColumnInfo13 = new DevExpress.DataAccess.Sql.RelationColumnInfo();
            DevExpress.DataAccess.Sql.Join join14 = new DevExpress.DataAccess.Sql.Join();
            DevExpress.DataAccess.Sql.RelationColumnInfo relationColumnInfo14 = new DevExpress.DataAccess.Sql.RelationColumnInfo();
            DevExpress.DataAccess.Sql.Sorting sorting3 = new DevExpress.DataAccess.Sql.Sorting();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression112 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Sorting sorting4 = new DevExpress.DataAccess.Sql.Sorting();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression113 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery9 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column110 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression114 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table22 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column111 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression115 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column112 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression116 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column113 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression117 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column114 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression118 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column115 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression119 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column116 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression120 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column117 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression121 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column118 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression122 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column119 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression123 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column120 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression124 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column121 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression125 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column122 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression126 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery10 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column123 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression127 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table23 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column124 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression128 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column125 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression129 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column126 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression130 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column127 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression131 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column128 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression132 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery11 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column129 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression133 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table24 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column130 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression134 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column131 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression135 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column132 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression136 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column133 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression137 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column134 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression138 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column135 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression139 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column136 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression140 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column137 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression141 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column138 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression142 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column139 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression143 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column140 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression144 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column141 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression145 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery12 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column142 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression146 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table25 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column143 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression147 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column144 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression148 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column145 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression149 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column146 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression150 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column147 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression151 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column148 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression152 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column149 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression153 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column150 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression154 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column151 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression155 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column152 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression156 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery13 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column153 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression157 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table26 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column154 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression158 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column155 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression159 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column156 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression160 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column157 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression161 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column158 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression162 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column159 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression163 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column160 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression164 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery14 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column161 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression165 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table27 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column162 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression166 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column163 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression167 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column164 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression168 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column165 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression169 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.SelectQuery selectQuery15 = new DevExpress.DataAccess.Sql.SelectQuery();
            DevExpress.DataAccess.Sql.Column column166 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression170 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Table table28 = new DevExpress.DataAccess.Sql.Table();
            DevExpress.DataAccess.Sql.Column column167 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression171 = new DevExpress.DataAccess.Sql.ColumnExpression();
            DevExpress.DataAccess.Sql.Column column168 = new DevExpress.DataAccess.Sql.Column();
            DevExpress.DataAccess.Sql.ColumnExpression columnExpression172 = new DevExpress.DataAccess.Sql.ColumnExpression();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(rep_pro_certification_checklists));
            this.Detail = new DevExpress.XtraReports.UI.DetailBand();
            this.TopMargin = new DevExpress.XtraReports.UI.TopMarginBand();
            this.BottomMargin = new DevExpress.XtraReports.UI.BottomMarginBand();
            this.sqlDataSource1 = new DevExpress.DataAccess.Sql.SqlDataSource(this.components);
            this.reportHeaderBand1 = new DevExpress.XtraReports.UI.ReportHeaderBand();
            this.detailReportBand1 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.groupHeaderBand1 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.detailBand1 = new DevExpress.XtraReports.UI.DetailBand();
            this.detailReportBand2 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.groupHeaderBand2 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.detailBand2 = new DevExpress.XtraReports.UI.DetailBand();
            this.detailReportBand5 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.groupHeaderBand5 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.detailBand5 = new DevExpress.XtraReports.UI.DetailBand();
            this.detailReportBand6 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.groupHeaderBand6 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.detailBand6 = new DevExpress.XtraReports.UI.DetailBand();
            this.detailReportBand7 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.groupHeaderBand7 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.detailBand7 = new DevExpress.XtraReports.UI.DetailBand();
            this.detailReportBand8 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.groupHeaderBand8 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.detailBand8 = new DevExpress.XtraReports.UI.DetailBand();
            this.detailReportBand9 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.groupHeaderBand9 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.detailBand9 = new DevExpress.XtraReports.UI.DetailBand();
            this.detailReportBand10 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.groupHeaderBand10 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.detailBand10 = new DevExpress.XtraReports.UI.DetailBand();
            this.detailReportBand11 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.groupHeaderBand11 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.detailBand11 = new DevExpress.XtraReports.UI.DetailBand();
            this.detailReportBand12 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.groupHeaderBand12 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.detailBand12 = new DevExpress.XtraReports.UI.DetailBand();
            this.detailReportBand13 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.groupHeaderBand13 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.detailBand13 = new DevExpress.XtraReports.UI.DetailBand();
            this.detailReportBand14 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.groupHeaderBand14 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.detailBand14 = new DevExpress.XtraReports.UI.DetailBand();
            this.Title = new DevExpress.XtraReports.UI.XRControlStyle();
            this.DetailCaption3 = new DevExpress.XtraReports.UI.XRControlStyle();
            this.DetailData3 = new DevExpress.XtraReports.UI.XRControlStyle();
            this.DetailData3_Odd = new DevExpress.XtraReports.UI.XRControlStyle();
            this.DetailCaptionBackground3 = new DevExpress.XtraReports.UI.XRControlStyle();
            this.PageInfo = new DevExpress.XtraReports.UI.XRControlStyle();
            this.PageHeader = new DevExpress.XtraReports.UI.PageHeaderBand();
            this.PageFooter = new DevExpress.XtraReports.UI.PageFooterBand();
            this.xrPageInfo1 = new DevExpress.XtraReports.UI.XRPageInfo();
            this.xrLabel7 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrPageInfo2 = new DevExpress.XtraReports.UI.XRPageInfo();
            this.xrLabel8 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel12 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel1 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel2 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTable1 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow1 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell1 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel3 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel4 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel5 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel6 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTable2 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow2 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell2 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell3 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell4 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell5 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel9 = new DevExpress.XtraReports.UI.XRLabel();
            this.GroupHeader1 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.xrLabel10 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel11 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel13 = new DevExpress.XtraReports.UI.XRLabel();
            this.formattingRule1 = new DevExpress.XtraReports.UI.FormattingRule();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // Detail
            // 
            this.Detail.HeightF = 0F;
            this.Detail.Name = "Detail";
            this.Detail.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Detail.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // TopMargin
            // 
            this.TopMargin.HeightF = 23.95833F;
            this.TopMargin.Name = "TopMargin";
            this.TopMargin.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.TopMargin.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // BottomMargin
            // 
            this.BottomMargin.HeightF = 23.95833F;
            this.BottomMargin.Name = "BottomMargin";
            this.BottomMargin.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.BottomMargin.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // sqlDataSource1
            // 
            this.sqlDataSource1.ConnectionName = "DevDB";
            this.sqlDataSource1.Name = "sqlDataSource1";
            columnExpression1.ColumnName = "ch_id";
            table1.Name = "rc_rtm_checklists";
            columnExpression1.Table = table1;
            column1.Expression = columnExpression1;
            columnExpression2.ColumnName = "ch_title";
            columnExpression2.Table = table1;
            column2.Expression = columnExpression2;
            columnExpression3.ColumnName = "ch_deleted";
            columnExpression3.Table = table1;
            column3.Expression = columnExpression3;
            columnExpression4.ColumnName = "ch_description";
            columnExpression4.Table = table1;
            column4.Expression = columnExpression4;
            selectQuery1.Columns.Add(column1);
            selectQuery1.Columns.Add(column2);
            selectQuery1.Columns.Add(column3);
            selectQuery1.Columns.Add(column4);
            selectQuery1.Name = "rc_rtm_checklists";
            selectQuery1.Tables.Add(table1);
            columnExpression5.ColumnName = "src_id";
            table2.MetaSerializable = "<Meta X=\"30\" Y=\"30\" Width=\"125\" Height=\"248\" />";
            table2.Name = "rc_rtm_criteria";
            columnExpression5.Table = table2;
            column5.Expression = columnExpression5;
            columnExpression6.ColumnName = "src_objective";
            columnExpression6.Table = table2;
            column6.Expression = columnExpression6;
            columnExpression7.ColumnName = "src_title";
            columnExpression7.Table = table2;
            column7.Expression = columnExpression7;
            columnExpression8.ColumnName = "src_unique_name";
            columnExpression8.Table = table2;
            column8.Expression = columnExpression8;
            columnExpression9.ColumnName = "src_criteria";
            columnExpression9.Table = table2;
            column9.Expression = columnExpression9;
            columnExpression10.ColumnName = "src_unique_order";
            columnExpression10.Table = table2;
            column10.Expression = columnExpression10;
            columnExpression11.ColumnName = "src_composite_name";
            columnExpression11.Table = table2;
            column11.Expression = columnExpression11;
            columnExpression12.ColumnName = "src_source";
            columnExpression12.Table = table2;
            column12.Expression = columnExpression12;
            columnExpression13.ColumnName = "src_deleted";
            columnExpression13.Table = table2;
            column13.Expression = columnExpression13;
            columnExpression14.ColumnName = "src_critical";
            columnExpression14.Table = table2;
            column14.Expression = columnExpression14;
            columnExpression15.ColumnName = "bo_id";
            table3.MetaSerializable = "<Meta X=\"185\" Y=\"30\" Width=\"125\" Height=\"153\" />";
            table3.Name = "rc_rtm_objectives";
            columnExpression15.Table = table3;
            column15.Expression = columnExpression15;
            columnExpression16.ColumnName = "bo_checklist";
            columnExpression16.Table = table3;
            column16.Expression = columnExpression16;
            columnExpression17.ColumnName = "bo_unique_id";
            columnExpression17.Table = table3;
            column17.Expression = columnExpression17;
            columnExpression18.ColumnName = "bo_name";
            columnExpression18.Table = table3;
            column18.Expression = columnExpression18;
            columnExpression19.ColumnName = "bo_deleted";
            columnExpression19.Table = table3;
            column19.Expression = columnExpression19;
            columnExpression20.ColumnName = "ch_id";
            table4.MetaSerializable = "<Meta X=\"340\" Y=\"30\" Width=\"125\" Height=\"134\" />";
            table4.Name = "rc_rtm_checklists";
            columnExpression20.Table = table4;
            column20.Expression = columnExpression20;
            columnExpression21.ColumnName = "ch_title";
            columnExpression21.Table = table4;
            column21.Expression = columnExpression21;
            columnExpression22.ColumnName = "ch_deleted";
            columnExpression22.Table = table4;
            column22.Expression = columnExpression22;
            columnExpression23.ColumnName = "ch_description";
            columnExpression23.Table = table4;
            column23.Expression = columnExpression23;
            columnExpression24.ColumnName = "act_id";
            table5.MetaSerializable = "<Meta X=\"590\" Y=\"240\" Width=\"125\" Height=\"134\" />";
            table5.Name = "rc_rtm_active";
            columnExpression24.Table = table5;
            column24.Expression = columnExpression24;
            columnExpression25.ColumnName = "act_checklist";
            columnExpression25.Table = table5;
            column25.Expression = columnExpression25;
            columnExpression26.ColumnName = "act_projectID";
            columnExpression26.Table = table5;
            column26.Expression = columnExpression26;
            columnExpression27.ColumnName = "act_isacctive";
            columnExpression27.Table = table5;
            column27.Expression = columnExpression27;
            columnExpression28.ColumnName = "pro_ID";
            table6.MetaSerializable = "<Meta X=\"780\" Y=\"140\" Width=\"125\" Height=\"153\" />";
            table6.Name = "rc_projects";
            columnExpression28.Table = table6;
            column28.Expression = columnExpression28;
            columnExpression29.ColumnName = "pro_name";
            columnExpression29.Table = table6;
            column29.Expression = columnExpression29;
            columnExpression30.ColumnName = "pro_color";
            columnExpression30.Table = table6;
            column30.Expression = columnExpression30;
            columnExpression31.ColumnName = "pro_description";
            columnExpression31.Table = table6;
            column31.Expression = columnExpression31;
            columnExpression32.ColumnName = "pro_milestoneId";
            columnExpression32.Table = table6;
            column32.Expression = columnExpression32;
            columnExpression33.ColumnName = "project";
            table7.MetaSerializable = "<Meta X=\"740\" Y=\"420\" Width=\"125\" Height=\"343\" />";
            table7.Name = "AspNetUsers";
            columnExpression33.Table = table7;
            column33.Expression = columnExpression33;
            columnExpression34.ColumnName = "enterprise";
            columnExpression34.Table = table7;
            column34.Expression = columnExpression34;
            selectQuery2.Columns.Add(column5);
            selectQuery2.Columns.Add(column6);
            selectQuery2.Columns.Add(column7);
            selectQuery2.Columns.Add(column8);
            selectQuery2.Columns.Add(column9);
            selectQuery2.Columns.Add(column10);
            selectQuery2.Columns.Add(column11);
            selectQuery2.Columns.Add(column12);
            selectQuery2.Columns.Add(column13);
            selectQuery2.Columns.Add(column14);
            selectQuery2.Columns.Add(column15);
            selectQuery2.Columns.Add(column16);
            selectQuery2.Columns.Add(column17);
            selectQuery2.Columns.Add(column18);
            selectQuery2.Columns.Add(column19);
            selectQuery2.Columns.Add(column20);
            selectQuery2.Columns.Add(column21);
            selectQuery2.Columns.Add(column22);
            selectQuery2.Columns.Add(column23);
            selectQuery2.Columns.Add(column24);
            selectQuery2.Columns.Add(column25);
            selectQuery2.Columns.Add(column26);
            selectQuery2.Columns.Add(column27);
            selectQuery2.Columns.Add(column28);
            selectQuery2.Columns.Add(column29);
            selectQuery2.Columns.Add(column30);
            selectQuery2.Columns.Add(column31);
            selectQuery2.Columns.Add(column32);
            selectQuery2.Columns.Add(column33);
            selectQuery2.Columns.Add(column34);
            selectQuery2.Distinct = true;
            selectQuery2.FilterString = "Not IsNullOrEmpty([rc_rtm_criteria.src_title])";
            selectQuery2.GroupFilterString = "";
            selectQuery2.Name = "rc_rtm_criteria";
            relationColumnInfo1.NestedKeyColumn = "bo_id";
            relationColumnInfo1.ParentKeyColumn = "src_objective";
            join1.KeyColumns.Add(relationColumnInfo1);
            join1.Nested = table3;
            join1.Parent = table2;
            relationColumnInfo2.NestedKeyColumn = "ch_id";
            relationColumnInfo2.ParentKeyColumn = "bo_checklist";
            join2.KeyColumns.Add(relationColumnInfo2);
            join2.Nested = table4;
            join2.Parent = table3;
            relationColumnInfo3.NestedKeyColumn = "pro_ID";
            relationColumnInfo3.ParentKeyColumn = "act_projectID";
            join3.KeyColumns.Add(relationColumnInfo3);
            join3.Nested = table6;
            join3.Parent = table5;
            relationColumnInfo4.NestedKeyColumn = "act_checklist";
            relationColumnInfo4.ParentKeyColumn = "ch_id";
            join4.KeyColumns.Add(relationColumnInfo4);
            join4.Nested = table5;
            join4.Parent = table4;
            join4.Type = DevExpress.Xpo.DB.JoinType.LeftOuter;
            relationColumnInfo5.NestedKeyColumn = "project";
            relationColumnInfo5.ParentKeyColumn = "pro_ID";
            join5.KeyColumns.Add(relationColumnInfo5);
            join5.Nested = table7;
            join5.Parent = table6;
            join5.Type = DevExpress.Xpo.DB.JoinType.LeftOuter;
            selectQuery2.Relations.Add(join1);
            selectQuery2.Relations.Add(join2);
            selectQuery2.Relations.Add(join3);
            selectQuery2.Relations.Add(join4);
            selectQuery2.Relations.Add(join5);
            columnExpression35.ColumnName = "pro_name";
            columnExpression35.Table = table6;
            sorting1.Expression = columnExpression35;
            columnExpression36.ColumnName = "src_title";
            columnExpression36.Table = table2;
            sorting2.Expression = columnExpression36;
            selectQuery2.Sorting.Add(sorting1);
            selectQuery2.Sorting.Add(sorting2);
            selectQuery2.Tables.Add(table2);
            selectQuery2.Tables.Add(table3);
            selectQuery2.Tables.Add(table4);
            selectQuery2.Tables.Add(table5);
            selectQuery2.Tables.Add(table6);
            selectQuery2.Tables.Add(table7);
            columnExpression37.ColumnName = "bo_id";
            table8.Name = "rc_rtm_objectives";
            columnExpression37.Table = table8;
            column35.Expression = columnExpression37;
            columnExpression38.ColumnName = "bo_checklist";
            columnExpression38.Table = table8;
            column36.Expression = columnExpression38;
            columnExpression39.ColumnName = "bo_unique_id";
            columnExpression39.Table = table8;
            column37.Expression = columnExpression39;
            columnExpression40.ColumnName = "bo_name";
            columnExpression40.Table = table8;
            column38.Expression = columnExpression40;
            columnExpression41.ColumnName = "bo_deleted";
            columnExpression41.Table = table8;
            column39.Expression = columnExpression41;
            selectQuery3.Columns.Add(column35);
            selectQuery3.Columns.Add(column36);
            selectQuery3.Columns.Add(column37);
            selectQuery3.Columns.Add(column38);
            selectQuery3.Columns.Add(column39);
            selectQuery3.Name = "rc_rtm_objectives";
            selectQuery3.Tables.Add(table8);
            columnExpression42.ColumnName = "act_id";
            table9.Name = "rc_rtm_active";
            columnExpression42.Table = table9;
            column40.Expression = columnExpression42;
            columnExpression43.ColumnName = "act_checklist";
            columnExpression43.Table = table9;
            column41.Expression = columnExpression43;
            columnExpression44.ColumnName = "act_projectID";
            columnExpression44.Table = table9;
            column42.Expression = columnExpression44;
            columnExpression45.ColumnName = "act_isacctive";
            columnExpression45.Table = table9;
            column43.Expression = columnExpression45;
            selectQuery4.Columns.Add(column40);
            selectQuery4.Columns.Add(column41);
            selectQuery4.Columns.Add(column42);
            selectQuery4.Columns.Add(column43);
            selectQuery4.Name = "rc_rtm_active";
            selectQuery4.Tables.Add(table9);
            columnExpression46.ColumnName = "desc_id";
            table10.Name = "rc_description";
            columnExpression46.Table = table10;
            column44.Expression = columnExpression46;
            columnExpression47.ColumnName = "desc_itemkey";
            columnExpression47.Table = table10;
            column45.Expression = columnExpression47;
            columnExpression48.ColumnName = "desc_description";
            columnExpression48.Table = table10;
            column46.Expression = columnExpression48;
            selectQuery5.Columns.Add(column44);
            selectQuery5.Columns.Add(column45);
            selectQuery5.Columns.Add(column46);
            selectQuery5.Name = "rc_description";
            selectQuery5.Tables.Add(table10);
            columnExpression49.ColumnName = "res_id";
            table11.Name = "rc_responses";
            columnExpression49.Table = table11;
            column47.Expression = columnExpression49;
            columnExpression50.ColumnName = "res_projectID";
            columnExpression50.Table = table11;
            column48.Expression = columnExpression50;
            columnExpression51.ColumnName = "res_itemID";
            columnExpression51.Table = table11;
            column49.Expression = columnExpression51;
            columnExpression52.ColumnName = "res_milestoneID";
            columnExpression52.Table = table11;
            column50.Expression = columnExpression52;
            columnExpression53.ColumnName = "res_response";
            columnExpression53.Table = table11;
            column51.Expression = columnExpression53;
            columnExpression54.ColumnName = "res_assessment";
            columnExpression54.Table = table11;
            column52.Expression = columnExpression54;
            columnExpression55.ColumnName = "res_date";
            columnExpression55.Table = table11;
            column53.Expression = columnExpression55;
            selectQuery6.Columns.Add(column47);
            selectQuery6.Columns.Add(column48);
            selectQuery6.Columns.Add(column49);
            selectQuery6.Columns.Add(column50);
            selectQuery6.Columns.Add(column51);
            selectQuery6.Columns.Add(column52);
            selectQuery6.Columns.Add(column53);
            selectQuery6.Name = "rc_responses";
            selectQuery6.Tables.Add(table11);
            columnExpression56.ColumnName = "wf_id";
            table12.Name = "rc_workflow";
            columnExpression56.Table = table12;
            column54.Expression = columnExpression56;
            columnExpression57.ColumnName = "wf_itemkey";
            columnExpression57.Table = table12;
            column55.Expression = columnExpression57;
            columnExpression58.ColumnName = "wf_projectid";
            columnExpression58.Table = table12;
            column56.Expression = columnExpression58;
            columnExpression59.ColumnName = "wf_status";
            columnExpression59.Table = table12;
            column57.Expression = columnExpression59;
            columnExpression60.ColumnName = "wf_status_value";
            columnExpression60.Table = table12;
            column58.Expression = columnExpression60;
            columnExpression61.ColumnName = "wf_comments";
            columnExpression61.Table = table12;
            column59.Expression = columnExpression61;
            columnExpression62.ColumnName = "wf_to";
            columnExpression62.Table = table12;
            column60.Expression = columnExpression62;
            columnExpression63.ColumnName = "wf_from";
            columnExpression63.Table = table12;
            column61.Expression = columnExpression63;
            columnExpression64.ColumnName = "wf_duedate";
            columnExpression64.Table = table12;
            column62.Expression = columnExpression64;
            columnExpression65.ColumnName = "wf_statusdate";
            columnExpression65.Table = table12;
            column63.Expression = columnExpression65;
            selectQuery7.Columns.Add(column54);
            selectQuery7.Columns.Add(column55);
            selectQuery7.Columns.Add(column56);
            selectQuery7.Columns.Add(column57);
            selectQuery7.Columns.Add(column58);
            selectQuery7.Columns.Add(column59);
            selectQuery7.Columns.Add(column60);
            selectQuery7.Columns.Add(column61);
            selectQuery7.Columns.Add(column62);
            selectQuery7.Columns.Add(column63);
            selectQuery7.Name = "rc_workflow";
            selectQuery7.Tables.Add(table12);
            columnExpression66.ColumnName = "pro_ID";
            table13.MetaSerializable = "<Meta X=\"30\" Y=\"30\" Width=\"125\" Height=\"153\" />";
            table13.Name = "rc_projects";
            columnExpression66.Table = table13;
            column64.Expression = columnExpression66;
            columnExpression67.ColumnName = "pro_name";
            columnExpression67.Table = table13;
            column65.Expression = columnExpression67;
            columnExpression68.ColumnName = "pro_color";
            columnExpression68.Table = table13;
            column66.Expression = columnExpression68;
            columnExpression69.ColumnName = "pro_description";
            columnExpression69.Table = table13;
            column67.Expression = columnExpression69;
            columnExpression70.ColumnName = "pro_milestoneId";
            columnExpression70.Table = table13;
            column68.Expression = columnExpression70;
            columnExpression71.ColumnName = "act_projectID";
            table14.MetaSerializable = "<Meta X=\"185\" Y=\"30\" Width=\"125\" Height=\"134\" />";
            table14.Name = "rc_rtm_active";
            columnExpression71.Table = table14;
            column69.Expression = columnExpression71;
            columnExpression72.ColumnName = "act_checklist";
            columnExpression72.Table = table14;
            column70.Expression = columnExpression72;
            columnExpression73.ColumnName = "ch_id";
            table15.MetaSerializable = "<Meta X=\"340\" Y=\"30\" Width=\"125\" Height=\"134\" />";
            table15.Name = "rc_rtm_checklists";
            columnExpression73.Table = table15;
            column71.Expression = columnExpression73;
            columnExpression74.ColumnName = "ch_title";
            columnExpression74.Table = table15;
            column72.Expression = columnExpression74;
            columnExpression75.ColumnName = "ch_deleted";
            columnExpression75.Table = table15;
            column73.Expression = columnExpression75;
            columnExpression76.ColumnName = "ch_description";
            columnExpression76.Table = table15;
            column74.Expression = columnExpression76;
            columnExpression77.ColumnName = "bo_id";
            table16.MetaSerializable = "<Meta X=\"495\" Y=\"30\" Width=\"125\" Height=\"153\" />";
            table16.Name = "rc_rtm_objectives";
            columnExpression77.Table = table16;
            column75.Expression = columnExpression77;
            columnExpression78.ColumnName = "bo_checklist";
            columnExpression78.Table = table16;
            column76.Expression = columnExpression78;
            columnExpression79.ColumnName = "bo_unique_id";
            columnExpression79.Table = table16;
            column77.Expression = columnExpression79;
            columnExpression80.ColumnName = "bo_name";
            columnExpression80.Table = table16;
            column78.Expression = columnExpression80;
            columnExpression81.ColumnName = "bo_deleted";
            columnExpression81.Table = table16;
            column79.Expression = columnExpression81;
            columnExpression82.ColumnName = "src_id";
            table17.MetaSerializable = "<Meta X=\"650\" Y=\"30\" Width=\"125\" Height=\"248\" />";
            table17.Name = "rc_rtm_criteria";
            columnExpression82.Table = table17;
            column80.Expression = columnExpression82;
            columnExpression83.ColumnName = "src_objective";
            columnExpression83.Table = table17;
            column81.Expression = columnExpression83;
            columnExpression84.ColumnName = "src_title";
            columnExpression84.Table = table17;
            column82.Expression = columnExpression84;
            columnExpression85.ColumnName = "src_unique_name";
            columnExpression85.Table = table17;
            column83.Expression = columnExpression85;
            columnExpression86.ColumnName = "src_criteria";
            columnExpression86.Table = table17;
            column84.Expression = columnExpression86;
            columnExpression87.ColumnName = "src_unique_order";
            columnExpression87.Table = table17;
            column85.Expression = columnExpression87;
            columnExpression88.ColumnName = "src_composite_name";
            columnExpression88.Table = table17;
            column86.Expression = columnExpression88;
            columnExpression89.ColumnName = "src_source";
            columnExpression89.Table = table17;
            column87.Expression = columnExpression89;
            columnExpression90.ColumnName = "src_deleted";
            columnExpression90.Table = table17;
            column88.Expression = columnExpression90;
            columnExpression91.ColumnName = "src_critical";
            columnExpression91.Table = table17;
            column89.Expression = columnExpression91;
            columnExpression92.ColumnName = "act_isacctive";
            columnExpression92.Table = table14;
            column90.Expression = columnExpression92;
            columnExpression93.ColumnName = "act_id";
            columnExpression93.Table = table14;
            column91.Expression = columnExpression93;
            column92.Alias = "rc_projects_1_pro_ID";
            columnExpression94.ColumnName = "pro_ID";
            table18.Alias = "rc_projects_1";
            table18.MetaSerializable = "<Meta X=\"805\" Y=\"30\" Width=\"125\" Height=\"153\" />";
            table18.Name = "rc_projects";
            columnExpression94.Table = table18;
            column92.Expression = columnExpression94;
            column93.Alias = "rc_projects_1_pro_name";
            columnExpression95.ColumnName = "pro_name";
            columnExpression95.Table = table18;
            column93.Expression = columnExpression95;
            column94.Alias = "rc_projects_1_pro_color";
            columnExpression96.ColumnName = "pro_color";
            columnExpression96.Table = table18;
            column94.Expression = columnExpression96;
            column95.Alias = "rc_projects_1_pro_description";
            columnExpression97.ColumnName = "pro_description";
            columnExpression97.Table = table18;
            column95.Expression = columnExpression97;
            column96.Alias = "rc_projects_1_pro_milestoneId";
            columnExpression98.ColumnName = "pro_milestoneId";
            columnExpression98.Table = table18;
            column96.Expression = columnExpression98;
            column97.Alias = "rc_rtm_checklists_1_ch_id";
            columnExpression99.ColumnName = "ch_id";
            table19.Alias = "rc_rtm_checklists_1";
            table19.MetaSerializable = "<Meta X=\"960\" Y=\"30\" Width=\"125\" Height=\"134\" />";
            table19.Name = "rc_rtm_checklists";
            columnExpression99.Table = table19;
            column97.Expression = columnExpression99;
            column98.Alias = "rc_rtm_checklists_1_ch_title";
            columnExpression100.ColumnName = "ch_title";
            columnExpression100.Table = table19;
            column98.Expression = columnExpression100;
            column99.Alias = "rc_rtm_checklists_1_ch_deleted";
            columnExpression101.ColumnName = "ch_deleted";
            columnExpression101.Table = table19;
            column99.Expression = columnExpression101;
            column100.Alias = "rc_rtm_checklists_1_ch_description";
            columnExpression102.ColumnName = "ch_description";
            columnExpression102.Table = table19;
            column100.Expression = columnExpression102;
            column101.Alias = "rc_rtm_objectives_1_bo_id";
            columnExpression103.ColumnName = "bo_id";
            table20.Alias = "rc_rtm_objectives_1";
            table20.MetaSerializable = "<Meta X=\"1115\" Y=\"30\" Width=\"125\" Height=\"153\" />";
            table20.Name = "rc_rtm_objectives";
            columnExpression103.Table = table20;
            column101.Expression = columnExpression103;
            column102.Alias = "rc_rtm_objectives_1_bo_checklist";
            columnExpression104.ColumnName = "bo_checklist";
            columnExpression104.Table = table20;
            column102.Expression = columnExpression104;
            column103.Alias = "rc_rtm_objectives_1_bo_unique_id";
            columnExpression105.ColumnName = "bo_unique_id";
            columnExpression105.Table = table20;
            column103.Expression = columnExpression105;
            column104.Alias = "rc_rtm_objectives_1_bo_name";
            columnExpression106.ColumnName = "bo_name";
            columnExpression106.Table = table20;
            column104.Expression = columnExpression106;
            column105.Alias = "rc_rtm_objectives_1_bo_deleted";
            columnExpression107.ColumnName = "bo_deleted";
            columnExpression107.Table = table20;
            column105.Expression = columnExpression107;
            column106.Alias = "rc_assessment_active_act_id";
            columnExpression108.ColumnName = "act_id";
            table21.MetaSerializable = "<Meta X=\"1270\" Y=\"30\" Width=\"125\" Height=\"134\" />";
            table21.Name = "rc_assessment_active";
            columnExpression108.Table = table21;
            column106.Expression = columnExpression108;
            columnExpression109.ColumnName = "act_bpID";
            columnExpression109.Table = table21;
            column107.Expression = columnExpression109;
            column108.Alias = "rc_assessment_active_act_projectID";
            columnExpression110.ColumnName = "act_projectID";
            columnExpression110.Table = table21;
            column108.Expression = columnExpression110;
            column109.Alias = "rc_assessment_active_act_isacctive";
            columnExpression111.ColumnName = "act_isacctive";
            columnExpression111.Table = table21;
            column109.Expression = columnExpression111;
            selectQuery8.Columns.Add(column64);
            selectQuery8.Columns.Add(column65);
            selectQuery8.Columns.Add(column66);
            selectQuery8.Columns.Add(column67);
            selectQuery8.Columns.Add(column68);
            selectQuery8.Columns.Add(column69);
            selectQuery8.Columns.Add(column70);
            selectQuery8.Columns.Add(column71);
            selectQuery8.Columns.Add(column72);
            selectQuery8.Columns.Add(column73);
            selectQuery8.Columns.Add(column74);
            selectQuery8.Columns.Add(column75);
            selectQuery8.Columns.Add(column76);
            selectQuery8.Columns.Add(column77);
            selectQuery8.Columns.Add(column78);
            selectQuery8.Columns.Add(column79);
            selectQuery8.Columns.Add(column80);
            selectQuery8.Columns.Add(column81);
            selectQuery8.Columns.Add(column82);
            selectQuery8.Columns.Add(column83);
            selectQuery8.Columns.Add(column84);
            selectQuery8.Columns.Add(column85);
            selectQuery8.Columns.Add(column86);
            selectQuery8.Columns.Add(column87);
            selectQuery8.Columns.Add(column88);
            selectQuery8.Columns.Add(column89);
            selectQuery8.Columns.Add(column90);
            selectQuery8.Columns.Add(column91);
            selectQuery8.Columns.Add(column92);
            selectQuery8.Columns.Add(column93);
            selectQuery8.Columns.Add(column94);
            selectQuery8.Columns.Add(column95);
            selectQuery8.Columns.Add(column96);
            selectQuery8.Columns.Add(column97);
            selectQuery8.Columns.Add(column98);
            selectQuery8.Columns.Add(column99);
            selectQuery8.Columns.Add(column100);
            selectQuery8.Columns.Add(column101);
            selectQuery8.Columns.Add(column102);
            selectQuery8.Columns.Add(column103);
            selectQuery8.Columns.Add(column104);
            selectQuery8.Columns.Add(column105);
            selectQuery8.Columns.Add(column106);
            selectQuery8.Columns.Add(column107);
            selectQuery8.Columns.Add(column108);
            selectQuery8.Columns.Add(column109);
            selectQuery8.Name = "rc_projects";
            relationColumnInfo6.NestedKeyColumn = "act_projectID";
            relationColumnInfo6.ParentKeyColumn = "pro_ID";
            join6.KeyColumns.Add(relationColumnInfo6);
            join6.Nested = table14;
            join6.Parent = table13;
            relationColumnInfo7.NestedKeyColumn = "ch_id";
            relationColumnInfo7.ParentKeyColumn = "act_checklist";
            join7.KeyColumns.Add(relationColumnInfo7);
            join7.Nested = table15;
            join7.Parent = table14;
            relationColumnInfo8.NestedKeyColumn = "bo_checklist";
            relationColumnInfo8.ParentKeyColumn = "ch_id";
            join8.KeyColumns.Add(relationColumnInfo8);
            join8.Nested = table16;
            join8.Parent = table15;
            relationColumnInfo9.NestedKeyColumn = "src_objective";
            relationColumnInfo9.ParentKeyColumn = "bo_id";
            join9.KeyColumns.Add(relationColumnInfo9);
            join9.Nested = table17;
            join9.Parent = table16;
            relationColumnInfo10.NestedKeyColumn = "pro_ID";
            relationColumnInfo10.ParentKeyColumn = "act_projectID";
            join10.KeyColumns.Add(relationColumnInfo10);
            join10.Nested = table18;
            join10.Parent = table14;
            relationColumnInfo11.NestedKeyColumn = "ch_id";
            relationColumnInfo11.ParentKeyColumn = "bo_checklist";
            join11.KeyColumns.Add(relationColumnInfo11);
            join11.Nested = table19;
            join11.Parent = table16;
            relationColumnInfo12.NestedKeyColumn = "bo_id";
            relationColumnInfo12.ParentKeyColumn = "src_objective";
            join12.KeyColumns.Add(relationColumnInfo12);
            join12.Nested = table20;
            join12.Parent = table17;
            relationColumnInfo13.NestedKeyColumn = "act_projectID";
            relationColumnInfo13.ParentKeyColumn = "pro_ID";
            join13.KeyColumns.Add(relationColumnInfo13);
            join13.Nested = table21;
            join13.Parent = table13;
            relationColumnInfo14.NestedKeyColumn = "act_projectID";
            relationColumnInfo14.ParentKeyColumn = "pro_ID";
            join14.KeyColumns.Add(relationColumnInfo14);
            join14.Nested = table21;
            join14.Parent = table18;
            selectQuery8.Relations.Add(join6);
            selectQuery8.Relations.Add(join7);
            selectQuery8.Relations.Add(join8);
            selectQuery8.Relations.Add(join9);
            selectQuery8.Relations.Add(join10);
            selectQuery8.Relations.Add(join11);
            selectQuery8.Relations.Add(join12);
            selectQuery8.Relations.Add(join13);
            selectQuery8.Relations.Add(join14);
            columnExpression112.ColumnName = "pro_name";
            columnExpression112.Table = table18;
            sorting3.Expression = columnExpression112;
            columnExpression113.ColumnName = "src_title";
            columnExpression113.Table = table17;
            sorting4.Expression = columnExpression113;
            selectQuery8.Sorting.Add(sorting3);
            selectQuery8.Sorting.Add(sorting4);
            selectQuery8.Tables.Add(table13);
            selectQuery8.Tables.Add(table14);
            selectQuery8.Tables.Add(table15);
            selectQuery8.Tables.Add(table16);
            selectQuery8.Tables.Add(table17);
            selectQuery8.Tables.Add(table18);
            selectQuery8.Tables.Add(table19);
            selectQuery8.Tables.Add(table20);
            selectQuery8.Tables.Add(table21);
            columnExpression114.ColumnName = "lib_id";
            table22.Name = "rc_repository";
            columnExpression114.Table = table22;
            column110.Expression = columnExpression114;
            columnExpression115.ColumnName = "lib_projectID";
            columnExpression115.Table = table22;
            column111.Expression = columnExpression115;
            columnExpression116.ColumnName = "lib_title";
            columnExpression116.Table = table22;
            column112.Expression = columnExpression116;
            columnExpression117.ColumnName = "lib_type";
            columnExpression117.Table = table22;
            column113.Expression = columnExpression117;
            columnExpression118.ColumnName = "lib_home";
            columnExpression118.Table = table22;
            column114.Expression = columnExpression118;
            columnExpression119.ColumnName = "lib_filename";
            columnExpression119.Table = table22;
            column115.Expression = columnExpression119;
            columnExpression120.ColumnName = "lib_storagename";
            columnExpression120.Table = table22;
            column116.Expression = columnExpression120;
            columnExpression121.ColumnName = "lib_desc";
            columnExpression121.Table = table22;
            column117.Expression = columnExpression121;
            columnExpression122.ColumnName = "lib_textsearch";
            columnExpression122.Table = table22;
            column118.Expression = columnExpression122;
            columnExpression123.ColumnName = "lib_dateuploaded";
            columnExpression123.Table = table22;
            column119.Expression = columnExpression123;
            columnExpression124.ColumnName = "lib_uploadedby";
            columnExpression124.Table = table22;
            column120.Expression = columnExpression124;
            columnExpression125.ColumnName = "lib_deleted";
            columnExpression125.Table = table22;
            column121.Expression = columnExpression125;
            columnExpression126.ColumnName = "lib_changeby";
            columnExpression126.Table = table22;
            column122.Expression = columnExpression126;
            selectQuery9.Columns.Add(column110);
            selectQuery9.Columns.Add(column111);
            selectQuery9.Columns.Add(column112);
            selectQuery9.Columns.Add(column113);
            selectQuery9.Columns.Add(column114);
            selectQuery9.Columns.Add(column115);
            selectQuery9.Columns.Add(column116);
            selectQuery9.Columns.Add(column117);
            selectQuery9.Columns.Add(column118);
            selectQuery9.Columns.Add(column119);
            selectQuery9.Columns.Add(column120);
            selectQuery9.Columns.Add(column121);
            selectQuery9.Columns.Add(column122);
            selectQuery9.Name = "rc_repository";
            selectQuery9.Tables.Add(table22);
            columnExpression127.ColumnName = "att_id";
            table23.Name = "rc_repository_attachments";
            columnExpression127.Table = table23;
            column123.Expression = columnExpression127;
            columnExpression128.ColumnName = "att_itemid";
            columnExpression128.Table = table23;
            column124.Expression = columnExpression128;
            columnExpression129.ColumnName = "att_artifact";
            columnExpression129.Table = table23;
            column125.Expression = columnExpression129;
            columnExpression130.ColumnName = "att_projectid";
            columnExpression130.Table = table23;
            column126.Expression = columnExpression130;
            columnExpression131.ColumnName = "att_pageref";
            columnExpression131.Table = table23;
            column127.Expression = columnExpression131;
            columnExpression132.ColumnName = "att_date";
            columnExpression132.Table = table23;
            column128.Expression = columnExpression132;
            selectQuery10.Columns.Add(column123);
            selectQuery10.Columns.Add(column124);
            selectQuery10.Columns.Add(column125);
            selectQuery10.Columns.Add(column126);
            selectQuery10.Columns.Add(column127);
            selectQuery10.Columns.Add(column128);
            selectQuery10.Name = "rc_repository_attachments";
            selectQuery10.Tables.Add(table23);
            columnExpression133.ColumnName = "his_id";
            table24.Name = "rc_repository_history";
            columnExpression133.Table = table24;
            column129.Expression = columnExpression133;
            columnExpression134.ColumnName = "his_artifactID";
            columnExpression134.Table = table24;
            column130.Expression = columnExpression134;
            columnExpression135.ColumnName = "his_projectID";
            columnExpression135.Table = table24;
            column131.Expression = columnExpression135;
            columnExpression136.ColumnName = "his_title";
            columnExpression136.Table = table24;
            column132.Expression = columnExpression136;
            columnExpression137.ColumnName = "his_type";
            columnExpression137.Table = table24;
            column133.Expression = columnExpression137;
            columnExpression138.ColumnName = "his_home";
            columnExpression138.Table = table24;
            column134.Expression = columnExpression138;
            columnExpression139.ColumnName = "his_filename";
            columnExpression139.Table = table24;
            column135.Expression = columnExpression139;
            columnExpression140.ColumnName = "his_storagename";
            columnExpression140.Table = table24;
            column136.Expression = columnExpression140;
            columnExpression141.ColumnName = "his_desc";
            columnExpression141.Table = table24;
            column137.Expression = columnExpression141;
            columnExpression142.ColumnName = "his_textsearch";
            columnExpression142.Table = table24;
            column138.Expression = columnExpression142;
            columnExpression143.ColumnName = "his_changeddate";
            columnExpression143.Table = table24;
            column139.Expression = columnExpression143;
            columnExpression144.ColumnName = "his_changeby";
            columnExpression144.Table = table24;
            column140.Expression = columnExpression144;
            columnExpression145.ColumnName = "his_changetype";
            columnExpression145.Table = table24;
            column141.Expression = columnExpression145;
            selectQuery11.Columns.Add(column129);
            selectQuery11.Columns.Add(column130);
            selectQuery11.Columns.Add(column131);
            selectQuery11.Columns.Add(column132);
            selectQuery11.Columns.Add(column133);
            selectQuery11.Columns.Add(column134);
            selectQuery11.Columns.Add(column135);
            selectQuery11.Columns.Add(column136);
            selectQuery11.Columns.Add(column137);
            selectQuery11.Columns.Add(column138);
            selectQuery11.Columns.Add(column139);
            selectQuery11.Columns.Add(column140);
            selectQuery11.Columns.Add(column141);
            selectQuery11.Name = "rc_repository_history";
            selectQuery11.Tables.Add(table24);
            columnExpression146.ColumnName = "pm_id";
            table25.Name = "rc_pm";
            columnExpression146.Table = table25;
            column142.Expression = columnExpression146;
            columnExpression147.ColumnName = "pm_type";
            columnExpression147.Table = table25;
            column143.Expression = columnExpression147;
            columnExpression148.ColumnName = "pm_uniqueID";
            columnExpression148.Table = table25;
            column144.Expression = columnExpression148;
            columnExpression149.ColumnName = "pm_area";
            columnExpression149.Table = table25;
            column145.Expression = columnExpression149;
            columnExpression150.ColumnName = "pm_title";
            columnExpression150.Table = table25;
            column146.Expression = columnExpression150;
            columnExpression151.ColumnName = "pm_desc";
            columnExpression151.Table = table25;
            column147.Expression = columnExpression151;
            columnExpression152.ColumnName = "pm_solution";
            columnExpression152.Table = table25;
            column148.Expression = columnExpression152;
            columnExpression153.ColumnName = "pm_priority";
            columnExpression153.Table = table25;
            column149.Expression = columnExpression153;
            columnExpression154.ColumnName = "pm_status";
            columnExpression154.Table = table25;
            column150.Expression = columnExpression154;
            columnExpression155.ColumnName = "pm_createdby";
            columnExpression155.Table = table25;
            column151.Expression = columnExpression155;
            columnExpression156.ColumnName = "pm_createddate";
            columnExpression156.Table = table25;
            column152.Expression = columnExpression156;
            selectQuery12.Columns.Add(column142);
            selectQuery12.Columns.Add(column143);
            selectQuery12.Columns.Add(column144);
            selectQuery12.Columns.Add(column145);
            selectQuery12.Columns.Add(column146);
            selectQuery12.Columns.Add(column147);
            selectQuery12.Columns.Add(column148);
            selectQuery12.Columns.Add(column149);
            selectQuery12.Columns.Add(column150);
            selectQuery12.Columns.Add(column151);
            selectQuery12.Columns.Add(column152);
            selectQuery12.Name = "rc_pm";
            selectQuery12.Tables.Add(table25);
            columnExpression157.ColumnName = "eval_id";
            table26.Name = "rc_evaluation";
            columnExpression157.Table = table26;
            column153.Expression = columnExpression157;
            columnExpression158.ColumnName = "eval_responseID";
            columnExpression158.Table = table26;
            column154.Expression = columnExpression158;
            columnExpression159.ColumnName = "eval_reviewer_assessments";
            columnExpression159.Table = table26;
            column155.Expression = columnExpression159;
            columnExpression160.ColumnName = "eval_description";
            columnExpression160.Table = table26;
            column156.Expression = columnExpression160;
            columnExpression161.ColumnName = "eval_projectID";
            columnExpression161.Table = table26;
            column157.Expression = columnExpression161;
            columnExpression162.ColumnName = "eval_itemID";
            columnExpression162.Table = table26;
            column158.Expression = columnExpression162;
            columnExpression163.ColumnName = "eval_date";
            columnExpression163.Table = table26;
            column159.Expression = columnExpression163;
            columnExpression164.ColumnName = "eval_by";
            columnExpression164.Table = table26;
            column160.Expression = columnExpression164;
            selectQuery13.Columns.Add(column153);
            selectQuery13.Columns.Add(column154);
            selectQuery13.Columns.Add(column155);
            selectQuery13.Columns.Add(column156);
            selectQuery13.Columns.Add(column157);
            selectQuery13.Columns.Add(column158);
            selectQuery13.Columns.Add(column159);
            selectQuery13.Columns.Add(column160);
            selectQuery13.Name = "rc_evaluation";
            selectQuery13.Tables.Add(table26);
            columnExpression165.ColumnName = "mil_id";
            table27.Name = "rc_milestones";
            columnExpression165.Table = table27;
            column161.Expression = columnExpression165;
            columnExpression166.ColumnName = "mil_name";
            columnExpression166.Table = table27;
            column162.Expression = columnExpression166;
            columnExpression167.ColumnName = "mil_description";
            columnExpression167.Table = table27;
            column163.Expression = columnExpression167;
            columnExpression168.ColumnName = "mil_date";
            columnExpression168.Table = table27;
            column164.Expression = columnExpression168;
            columnExpression169.ColumnName = "IsStatic";
            columnExpression169.Table = table27;
            column165.Expression = columnExpression169;
            selectQuery14.Columns.Add(column161);
            selectQuery14.Columns.Add(column162);
            selectQuery14.Columns.Add(column163);
            selectQuery14.Columns.Add(column164);
            selectQuery14.Columns.Add(column165);
            selectQuery14.Name = "rc_milestones";
            selectQuery14.Tables.Add(table27);
            columnExpression170.ColumnName = "en_id";
            table28.MetaSerializable = "<Meta X=\"30\" Y=\"30\" Width=\"125\" Height=\"115\" />";
            table28.Name = "rc_enterprise";
            columnExpression170.Table = table28;
            column166.Expression = columnExpression170;
            columnExpression171.ColumnName = "en_name";
            columnExpression171.Table = table28;
            column167.Expression = columnExpression171;
            columnExpression172.ColumnName = "en_connstring";
            columnExpression172.Table = table28;
            column168.Expression = columnExpression172;
            selectQuery15.Columns.Add(column166);
            selectQuery15.Columns.Add(column167);
            selectQuery15.Columns.Add(column168);
            selectQuery15.Name = "rc_enterprise";
            selectQuery15.Tables.Add(table28);
            this.sqlDataSource1.Queries.AddRange(new DevExpress.DataAccess.Sql.SqlQuery[] {
            selectQuery1,
            selectQuery2,
            selectQuery3,
            selectQuery4,
            selectQuery5,
            selectQuery6,
            selectQuery7,
            selectQuery8,
            selectQuery9,
            selectQuery10,
            selectQuery11,
            selectQuery12,
            selectQuery13,
            selectQuery14,
            selectQuery15});
            this.sqlDataSource1.ResultSchemaSerializable = resources.GetString("sqlDataSource1.ResultSchemaSerializable");
            // 
            // reportHeaderBand1
            // 
            this.reportHeaderBand1.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel2});
            this.reportHeaderBand1.HeightF = 46.33334F;
            this.reportHeaderBand1.Name = "reportHeaderBand1";
            // 
            // detailReportBand1
            // 
            this.detailReportBand1.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.groupHeaderBand1,
            this.detailBand1});
            this.detailReportBand1.DataMember = "rc_rtm_checklists";
            this.detailReportBand1.DataSource = this.sqlDataSource1;
            this.detailReportBand1.FilterString = "[ch_deleted] = False";
            this.detailReportBand1.Level = 0;
            this.detailReportBand1.Name = "detailReportBand1";
            // 
            // groupHeaderBand1
            // 
            this.groupHeaderBand1.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel4,
            this.xrLabel3});
            this.groupHeaderBand1.GroupUnion = DevExpress.XtraReports.UI.GroupUnion.WithFirstDetail;
            this.groupHeaderBand1.HeightF = 30.29169F;
            this.groupHeaderBand1.Name = "groupHeaderBand1";
            // 
            // detailBand1
            // 
            this.detailBand1.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable1});
            this.detailBand1.HeightF = 25F;
            this.detailBand1.Name = "detailBand1";
            // 
            // detailReportBand2
            // 
            this.detailReportBand2.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.groupHeaderBand2,
            this.detailBand2,
            this.GroupHeader1});
            this.detailReportBand2.DataMember = "rc_projects";
            this.detailReportBand2.DataSource = this.sqlDataSource1;
            this.detailReportBand2.FilterString = "[pro_ID] = [act_projectID]";
            this.detailReportBand2.Level = 1;
            this.detailReportBand2.Name = "detailReportBand2";
            // 
            // groupHeaderBand2
            // 
            this.groupHeaderBand2.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel13,
            this.xrLabel11,
            this.xrLabel10,
            this.xrLabel9});
            this.groupHeaderBand2.GroupUnion = DevExpress.XtraReports.UI.GroupUnion.WholePage;
            this.groupHeaderBand2.HeightF = 23F;
            this.groupHeaderBand2.Name = "groupHeaderBand2";
            this.groupHeaderBand2.RepeatEveryPage = true;
            // 
            // detailBand2
            // 
            this.detailBand2.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable2});
            this.detailBand2.HeightF = 25F;
            this.detailBand2.Name = "detailBand2";
            // 
            // detailReportBand5
            // 
            this.detailReportBand5.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.groupHeaderBand5,
            this.detailBand5});
            this.detailReportBand5.DataMember = "rc_description";
            this.detailReportBand5.DataSource = this.sqlDataSource1;
            this.detailReportBand5.Level = 2;
            this.detailReportBand5.Name = "detailReportBand5";
            // 
            // groupHeaderBand5
            // 
            this.groupHeaderBand5.GroupUnion = DevExpress.XtraReports.UI.GroupUnion.WithFirstDetail;
            this.groupHeaderBand5.HeightF = 48F;
            this.groupHeaderBand5.Name = "groupHeaderBand5";
            // 
            // detailBand5
            // 
            this.detailBand5.HeightF = 25F;
            this.detailBand5.Name = "detailBand5";
            // 
            // detailReportBand6
            // 
            this.detailReportBand6.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.groupHeaderBand6,
            this.detailBand6});
            this.detailReportBand6.DataMember = "rc_responses";
            this.detailReportBand6.DataSource = this.sqlDataSource1;
            this.detailReportBand6.Level = 3;
            this.detailReportBand6.Name = "detailReportBand6";
            // 
            // groupHeaderBand6
            // 
            this.groupHeaderBand6.GroupUnion = DevExpress.XtraReports.UI.GroupUnion.WithFirstDetail;
            this.groupHeaderBand6.HeightF = 48F;
            this.groupHeaderBand6.Name = "groupHeaderBand6";
            // 
            // detailBand6
            // 
            this.detailBand6.HeightF = 25F;
            this.detailBand6.Name = "detailBand6";
            // 
            // detailReportBand7
            // 
            this.detailReportBand7.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.groupHeaderBand7,
            this.detailBand7});
            this.detailReportBand7.DataMember = "rc_workflow";
            this.detailReportBand7.DataSource = this.sqlDataSource1;
            this.detailReportBand7.Level = 4;
            this.detailReportBand7.Name = "detailReportBand7";
            // 
            // groupHeaderBand7
            // 
            this.groupHeaderBand7.GroupUnion = DevExpress.XtraReports.UI.GroupUnion.WithFirstDetail;
            this.groupHeaderBand7.HeightF = 48F;
            this.groupHeaderBand7.Name = "groupHeaderBand7";
            // 
            // detailBand7
            // 
            this.detailBand7.HeightF = 25F;
            this.detailBand7.Name = "detailBand7";
            // 
            // detailReportBand8
            // 
            this.detailReportBand8.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.groupHeaderBand8,
            this.detailBand8});
            this.detailReportBand8.DataMember = "rc_projects";
            this.detailReportBand8.DataSource = this.sqlDataSource1;
            this.detailReportBand8.Level = 5;
            this.detailReportBand8.Name = "detailReportBand8";
            // 
            // groupHeaderBand8
            // 
            this.groupHeaderBand8.GroupUnion = DevExpress.XtraReports.UI.GroupUnion.WithFirstDetail;
            this.groupHeaderBand8.HeightF = 48F;
            this.groupHeaderBand8.Name = "groupHeaderBand8";
            // 
            // detailBand8
            // 
            this.detailBand8.HeightF = 25F;
            this.detailBand8.Name = "detailBand8";
            // 
            // detailReportBand9
            // 
            this.detailReportBand9.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.groupHeaderBand9,
            this.detailBand9});
            this.detailReportBand9.DataMember = "rc_repository";
            this.detailReportBand9.DataSource = this.sqlDataSource1;
            this.detailReportBand9.Level = 6;
            this.detailReportBand9.Name = "detailReportBand9";
            // 
            // groupHeaderBand9
            // 
            this.groupHeaderBand9.GroupUnion = DevExpress.XtraReports.UI.GroupUnion.WithFirstDetail;
            this.groupHeaderBand9.HeightF = 48F;
            this.groupHeaderBand9.Name = "groupHeaderBand9";
            // 
            // detailBand9
            // 
            this.detailBand9.HeightF = 25F;
            this.detailBand9.Name = "detailBand9";
            // 
            // detailReportBand10
            // 
            this.detailReportBand10.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.groupHeaderBand10,
            this.detailBand10});
            this.detailReportBand10.DataMember = "rc_repository_attachments";
            this.detailReportBand10.DataSource = this.sqlDataSource1;
            this.detailReportBand10.Level = 7;
            this.detailReportBand10.Name = "detailReportBand10";
            // 
            // groupHeaderBand10
            // 
            this.groupHeaderBand10.GroupUnion = DevExpress.XtraReports.UI.GroupUnion.WithFirstDetail;
            this.groupHeaderBand10.HeightF = 48F;
            this.groupHeaderBand10.Name = "groupHeaderBand10";
            // 
            // detailBand10
            // 
            this.detailBand10.HeightF = 25F;
            this.detailBand10.Name = "detailBand10";
            // 
            // detailReportBand11
            // 
            this.detailReportBand11.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.groupHeaderBand11,
            this.detailBand11});
            this.detailReportBand11.DataMember = "rc_repository_history";
            this.detailReportBand11.DataSource = this.sqlDataSource1;
            this.detailReportBand11.Level = 8;
            this.detailReportBand11.Name = "detailReportBand11";
            // 
            // groupHeaderBand11
            // 
            this.groupHeaderBand11.GroupUnion = DevExpress.XtraReports.UI.GroupUnion.WithFirstDetail;
            this.groupHeaderBand11.HeightF = 48F;
            this.groupHeaderBand11.Name = "groupHeaderBand11";
            // 
            // detailBand11
            // 
            this.detailBand11.HeightF = 25F;
            this.detailBand11.Name = "detailBand11";
            // 
            // detailReportBand12
            // 
            this.detailReportBand12.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.groupHeaderBand12,
            this.detailBand12});
            this.detailReportBand12.DataMember = "rc_pm";
            this.detailReportBand12.DataSource = this.sqlDataSource1;
            this.detailReportBand12.Level = 9;
            this.detailReportBand12.Name = "detailReportBand12";
            // 
            // groupHeaderBand12
            // 
            this.groupHeaderBand12.GroupUnion = DevExpress.XtraReports.UI.GroupUnion.WithFirstDetail;
            this.groupHeaderBand12.HeightF = 48F;
            this.groupHeaderBand12.Name = "groupHeaderBand12";
            // 
            // detailBand12
            // 
            this.detailBand12.HeightF = 25F;
            this.detailBand12.Name = "detailBand12";
            // 
            // detailReportBand13
            // 
            this.detailReportBand13.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.groupHeaderBand13,
            this.detailBand13});
            this.detailReportBand13.DataMember = "rc_evaluation";
            this.detailReportBand13.DataSource = this.sqlDataSource1;
            this.detailReportBand13.Level = 10;
            this.detailReportBand13.Name = "detailReportBand13";
            // 
            // groupHeaderBand13
            // 
            this.groupHeaderBand13.GroupUnion = DevExpress.XtraReports.UI.GroupUnion.WithFirstDetail;
            this.groupHeaderBand13.HeightF = 48F;
            this.groupHeaderBand13.Name = "groupHeaderBand13";
            // 
            // detailBand13
            // 
            this.detailBand13.HeightF = 25F;
            this.detailBand13.Name = "detailBand13";
            // 
            // detailReportBand14
            // 
            this.detailReportBand14.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.groupHeaderBand14,
            this.detailBand14});
            this.detailReportBand14.DataMember = "rc_milestones";
            this.detailReportBand14.DataSource = this.sqlDataSource1;
            this.detailReportBand14.Level = 11;
            this.detailReportBand14.Name = "detailReportBand14";
            // 
            // groupHeaderBand14
            // 
            this.groupHeaderBand14.GroupUnion = DevExpress.XtraReports.UI.GroupUnion.WithFirstDetail;
            this.groupHeaderBand14.HeightF = 48F;
            this.groupHeaderBand14.Name = "groupHeaderBand14";
            // 
            // detailBand14
            // 
            this.detailBand14.HeightF = 25F;
            this.detailBand14.Name = "detailBand14";
            // 
            // Title
            // 
            this.Title.BackColor = System.Drawing.Color.Transparent;
            this.Title.BorderColor = System.Drawing.Color.Black;
            this.Title.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.Title.BorderWidth = 1F;
            this.Title.Font = new System.Drawing.Font("Tahoma", 14F);
            this.Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.Title.Name = "Title";
            // 
            // DetailCaption3
            // 
            this.DetailCaption3.BackColor = System.Drawing.Color.Transparent;
            this.DetailCaption3.BorderColor = System.Drawing.Color.Transparent;
            this.DetailCaption3.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.DetailCaption3.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.DetailCaption3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.DetailCaption3.Name = "DetailCaption3";
            this.DetailCaption3.Padding = new DevExpress.XtraPrinting.PaddingInfo(6, 6, 0, 0, 100F);
            this.DetailCaption3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // DetailData3
            // 
            this.DetailData3.Font = new System.Drawing.Font("Tahoma", 8F);
            this.DetailData3.ForeColor = System.Drawing.Color.Black;
            this.DetailData3.Name = "DetailData3";
            this.DetailData3.Padding = new DevExpress.XtraPrinting.PaddingInfo(6, 6, 0, 0, 100F);
            this.DetailData3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // DetailData3_Odd
            // 
            this.DetailData3_Odd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(231)))), ((int)(((byte)(231)))));
            this.DetailData3_Odd.BorderColor = System.Drawing.Color.Transparent;
            this.DetailData3_Odd.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.DetailData3_Odd.BorderWidth = 1F;
            this.DetailData3_Odd.Font = new System.Drawing.Font("Tahoma", 8F);
            this.DetailData3_Odd.ForeColor = System.Drawing.Color.Black;
            this.DetailData3_Odd.Name = "DetailData3_Odd";
            this.DetailData3_Odd.Padding = new DevExpress.XtraPrinting.PaddingInfo(6, 6, 0, 0, 100F);
            this.DetailData3_Odd.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // DetailCaptionBackground3
            // 
            this.DetailCaptionBackground3.BackColor = System.Drawing.Color.Transparent;
            this.DetailCaptionBackground3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
            this.DetailCaptionBackground3.Borders = DevExpress.XtraPrinting.BorderSide.Top;
            this.DetailCaptionBackground3.BorderWidth = 2F;
            this.DetailCaptionBackground3.Name = "DetailCaptionBackground3";
            // 
            // PageInfo
            // 
            this.PageInfo.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.PageInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.PageInfo.Name = "PageInfo";
            this.PageInfo.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            // 
            // PageHeader
            // 
            this.PageHeader.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel1});
            this.PageHeader.HeightF = 46.33334F;
            this.PageHeader.Name = "PageHeader";
            // 
            // PageFooter
            // 
            this.PageFooter.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrPageInfo1,
            this.xrLabel7,
            this.xrPageInfo2,
            this.xrLabel8,
            this.xrLabel12});
            this.PageFooter.HeightF = 100F;
            this.PageFooter.Name = "PageFooter";
            // 
            // xrPageInfo1
            // 
            this.xrPageInfo1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrPageInfo1.LocationFloat = new DevExpress.Utils.PointFloat(590.3959F, 40.36458F);
            this.xrPageInfo1.Name = "xrPageInfo1";
            this.xrPageInfo1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrPageInfo1.SizeF = new System.Drawing.SizeF(58.85419F, 35.50002F);
            this.xrPageInfo1.StylePriority.UseFont = false;
            this.xrPageInfo1.StylePriority.UseTextAlignment = false;
            this.xrPageInfo1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            // 
            // xrLabel7
            // 
            this.xrLabel7.Font = new System.Drawing.Font("Segoe UI", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel7.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrLabel7.Name = "xrLabel7";
            this.xrLabel7.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel7.SizeF = new System.Drawing.SizeF(197.2917F, 23.09373F);
            this.xrLabel7.StylePriority.UseFont = false;
            this.xrLabel7.StylePriority.UseTextAlignment = false;
            this.xrLabel7.Text = "Generated by ReadyCert® for";
            this.xrLabel7.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrPageInfo2
            // 
            this.xrPageInfo2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrPageInfo2.LocationFloat = new DevExpress.Utils.PointFloat(0F, 63.45831F);
            this.xrPageInfo2.Name = "xrPageInfo2";
            this.xrPageInfo2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrPageInfo2.PageInfo = DevExpress.XtraPrinting.PageInfo.DateTime;
            this.xrPageInfo2.SizeF = new System.Drawing.SizeF(269.2708F, 36.54169F);
            this.xrPageInfo2.StylePriority.UseFont = false;
            this.xrPageInfo2.StylePriority.UseTextAlignment = false;
            this.xrPageInfo2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // xrLabel8
            // 
            this.xrLabel8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel8.LocationFloat = new DevExpress.Utils.PointFloat(461.7499F, 40.36458F);
            this.xrLabel8.Name = "xrLabel8";
            this.xrLabel8.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel8.SizeF = new System.Drawing.SizeF(128.6458F, 35.50002F);
            this.xrLabel8.StylePriority.UseFont = false;
            this.xrLabel8.StylePriority.UseTextAlignment = false;
            this.xrLabel8.Text = "page";
            this.xrLabel8.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
            this.xrLabel8.TextTrimming = System.Drawing.StringTrimming.None;
            // 
            // xrLabel12
            // 
            this.xrLabel12.ExpressionBindings.AddRange(new DevExpress.XtraReports.UI.ExpressionBinding[] {
            new DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", "[rc_enterprise].[en_name]")});
            this.xrLabel12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xrLabel12.LocationFloat = new DevExpress.Utils.PointFloat(0F, 23.09373F);
            this.xrLabel12.Name = "xrLabel12";
            this.xrLabel12.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel12.SizeF = new System.Drawing.SizeF(424.7499F, 40.36459F);
            this.xrLabel12.StylePriority.UseFont = false;
            this.xrLabel12.StylePriority.UseTextAlignment = false;
            this.xrLabel12.Text = "CLIENT NAME";
            this.xrLabel12.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // xrLabel1
            // 
            this.xrLabel1.Borders = DevExpress.XtraPrinting.BorderSide.Left;
            this.xrLabel1.ExpressionBindings.AddRange(new DevExpress.XtraReports.UI.ExpressionBinding[] {
            new DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", "[rc_projects].[pro_name]")});
            this.xrLabel1.Font = new System.Drawing.Font("Segoe UI", 16F);
            this.xrLabel1.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrLabel1.Name = "xrLabel1";
            this.xrLabel1.Padding = new DevExpress.XtraPrinting.PaddingInfo(8, 2, 0, 0, 100F);
            this.xrLabel1.SizeF = new System.Drawing.SizeF(566.7083F, 46.33334F);
            this.xrLabel1.StylePriority.UseBorders = false;
            this.xrLabel1.StylePriority.UseFont = false;
            this.xrLabel1.StylePriority.UsePadding = false;
            this.xrLabel1.StylePriority.UseTextAlignment = false;
            this.xrLabel1.Text = "PROJECT NAME FIELD";
            this.xrLabel1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // xrLabel2
            // 
            this.xrLabel2.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrLabel2.Font = new System.Drawing.Font("Segoe UI", 16F);
            this.xrLabel2.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrLabel2.Name = "xrLabel2";
            this.xrLabel2.Padding = new DevExpress.XtraPrinting.PaddingInfo(8, 2, 0, 0, 100F);
            this.xrLabel2.SizeF = new System.Drawing.SizeF(566.7083F, 46.33334F);
            this.xrLabel2.StylePriority.UseBorders = false;
            this.xrLabel2.StylePriority.UseFont = false;
            this.xrLabel2.StylePriority.UsePadding = false;
            this.xrLabel2.StylePriority.UseTextAlignment = false;
            this.xrLabel2.Text = "Certification Checklist Summary";
            this.xrLabel2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // xrTable1
            // 
            this.xrTable1.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrTable1.Name = "xrTable1";
            this.xrTable1.Padding = new DevExpress.XtraPrinting.PaddingInfo(3, 0, 0, 0, 100F);
            this.xrTable1.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow1});
            this.xrTable1.SizeF = new System.Drawing.SizeF(650F, 25F);
            this.xrTable1.StylePriority.UsePadding = false;
            // 
            // xrTableRow1
            // 
            this.xrTableRow1.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell1});
            this.xrTableRow1.Name = "xrTableRow1";
            this.xrTableRow1.Weight = 1D;
            // 
            // xrTableCell1
            // 
            this.xrTableCell1.ExpressionBindings.AddRange(new DevExpress.XtraReports.UI.ExpressionBinding[] {
            new DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", "[ch_title]")});
            this.xrTableCell1.Name = "xrTableCell1";
            this.xrTableCell1.Text = "xrTableCell1";
            this.xrTableCell1.Weight = 1D;
            // 
            // xrLabel3
            // 
            this.xrLabel3.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel3.LocationFloat = new DevExpress.Utils.PointFloat(0F, 7.291685F);
            this.xrLabel3.Name = "xrLabel3";
            this.xrLabel3.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 96F);
            this.xrLabel3.SizeF = new System.Drawing.SizeF(168F, 23F);
            this.xrLabel3.StylePriority.UseBorders = false;
            this.xrLabel3.Text = "List of Checklists active for ";
            // 
            // xrLabel4
            // 
            this.xrLabel4.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel4.ExpressionBindings.AddRange(new DevExpress.XtraReports.UI.ExpressionBinding[] {
            new DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", "[rc_projects].[pro_name]")});
            this.xrLabel4.LocationFloat = new DevExpress.Utils.PointFloat(168F, 7.291685F);
            this.xrLabel4.Name = "xrLabel4";
            this.xrLabel4.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel4.SizeF = new System.Drawing.SizeF(481.25F, 23F);
            this.xrLabel4.StylePriority.UseBorders = false;
            // 
            // xrLabel5
            // 
            this.xrLabel5.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel5.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrLabel5.Name = "xrLabel5";
            this.xrLabel5.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel5.SizeF = new System.Drawing.SizeF(168F, 23F);
            this.xrLabel5.StylePriority.UseBorders = false;
            this.xrLabel5.Text = "List of Critera active for ";
            // 
            // xrLabel6
            // 
            this.xrLabel6.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel6.ExpressionBindings.AddRange(new DevExpress.XtraReports.UI.ExpressionBinding[] {
            new DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", "[rc_projects].[pro_name]")});
            this.xrLabel6.LocationFloat = new DevExpress.Utils.PointFloat(168F, 0F);
            this.xrLabel6.Name = "xrLabel6";
            this.xrLabel6.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel6.SizeF = new System.Drawing.SizeF(481.25F, 23F);
            this.xrLabel6.StylePriority.UseBorders = false;
            // 
            // xrTable2
            // 
            this.xrTable2.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrTable2.Name = "xrTable2";
            this.xrTable2.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow2});
            this.xrTable2.SizeF = new System.Drawing.SizeF(649.25F, 25F);
            // 
            // xrTableRow2
            // 
            this.xrTableRow2.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell2,
            this.xrTableCell3,
            this.xrTableCell4,
            this.xrTableCell5});
            this.xrTableRow2.Name = "xrTableRow2";
            this.xrTableRow2.Weight = 1D;
            // 
            // xrTableCell2
            // 
            this.xrTableCell2.ExpressionBindings.AddRange(new DevExpress.XtraReports.UI.ExpressionBinding[] {
            new DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", "[src_title]")});
            this.xrTableCell2.Name = "xrTableCell2";
            this.xrTableCell2.Text = "Criteria #";
            this.xrTableCell2.Weight = 0.46091648905287352D;
            // 
            // xrTableCell3
            // 
            this.xrTableCell3.ExpressionBindings.AddRange(new DevExpress.XtraReports.UI.ExpressionBinding[] {
            new DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", "[src_source]")});
            this.xrTableCell3.Name = "xrTableCell3";
            this.xrTableCell3.Text = "Criteria Source";
            this.xrTableCell3.Weight = 0.57643430031947929D;
            // 
            // xrTableCell4
            // 
            this.xrTableCell4.ExpressionBindings.AddRange(new DevExpress.XtraReports.UI.ExpressionBinding[] {
            new DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", "[src_critical]")});
            this.xrTableCell4.Name = "xrTableCell4";
            this.xrTableCell4.Text = "SRC CSF";
            this.xrTableCell4.Weight = 0.62161465227305546D;
            // 
            // xrTableCell5
            // 
            this.xrTableCell5.ExpressionBindings.AddRange(new DevExpress.XtraReports.UI.ExpressionBinding[] {
            new DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", "[src_criteria]")});
            this.xrTableCell5.Name = "xrTableCell5";
            this.xrTableCell5.Text = "Criteria Definition";
            this.xrTableCell5.Weight = 2.3410345583545915D;
            // 
            // xrLabel9
            // 
            this.xrLabel9.LocationFloat = new DevExpress.Utils.PointFloat(0.3749847F, 0F);
            this.xrLabel9.Name = "xrLabel9";
            this.xrLabel9.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 96F);
            this.xrLabel9.SizeF = new System.Drawing.SizeF(74.43752F, 23F);
            this.xrLabel9.Text = "SRC #";
            // 
            // GroupHeader1
            // 
            this.GroupHeader1.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel6,
            this.xrLabel5});
            this.GroupHeader1.HeightF = 23F;
            this.GroupHeader1.Level = 1;
            this.GroupHeader1.Name = "GroupHeader1";
            // 
            // xrLabel10
            // 
            this.xrLabel10.LocationFloat = new DevExpress.Utils.PointFloat(74.81251F, 0F);
            this.xrLabel10.Name = "xrLabel10";
            this.xrLabel10.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel10.SizeF = new System.Drawing.SizeF(93.18752F, 23F);
            this.xrLabel10.Text = "Source";
            // 
            // xrLabel11
            // 
            this.xrLabel11.LocationFloat = new DevExpress.Utils.PointFloat(168.375F, 0F);
            this.xrLabel11.Name = "xrLabel11";
            this.xrLabel11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel11.SizeF = new System.Drawing.SizeF(100.8958F, 23F);
            this.xrLabel11.Text = "CSF (T/F)";
            // 
            // xrLabel13
            // 
            this.xrLabel13.LocationFloat = new DevExpress.Utils.PointFloat(269.2708F, 0F);
            this.xrLabel13.Name = "xrLabel13";
            this.xrLabel13.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel13.SizeF = new System.Drawing.SizeF(379.9792F, 23F);
            this.xrLabel13.Text = "Criteria";
            // 
            // formattingRule1
            // 
            this.formattingRule1.DataMember = "rc_rtm_checklists";
            this.formattingRule1.Name = "formattingRule1";
            // 
            // rep_pro_certification_checklists
            // 
            this.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail,
            this.TopMargin,
            this.BottomMargin,
            this.reportHeaderBand1,
            this.detailReportBand1,
            this.detailReportBand2,
            this.detailReportBand5,
            this.detailReportBand6,
            this.detailReportBand7,
            this.detailReportBand8,
            this.detailReportBand9,
            this.detailReportBand10,
            this.detailReportBand11,
            this.detailReportBand12,
            this.detailReportBand13,
            this.detailReportBand14,
            this.PageHeader,
            this.PageFooter});
            this.ComponentStorage.AddRange(new System.ComponentModel.IComponent[] {
            this.sqlDataSource1});
            this.DataMember = "rc_rtm_checklists";
            this.DataSource = this.sqlDataSource1;
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margins = new System.Drawing.Printing.Margins(100, 100, 24, 24);
            this.StyleSheet.AddRange(new DevExpress.XtraReports.UI.XRControlStyle[] {
            this.Title,
            this.DetailCaption3,
            this.DetailData3,
            this.DetailData3_Odd,
            this.DetailCaptionBackground3,
            this.PageInfo});
            this.Version = "17.2";
            ((System.ComponentModel.ISupportInitialize)(this.xrTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

    }

    #endregion
}
